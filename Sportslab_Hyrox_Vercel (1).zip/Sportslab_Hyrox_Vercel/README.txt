SPORTSLAB – HYROX TESTBATTERI
Vercel-ready version

1. Lägg upp mappen i ett GitHub-repository.
2. Logga in på Vercel med GitHub.
3. Välj New Project och importera repositoryt.
4. Framework Preset: Other.
5. Build Command: lämnas tomt.
6. Klicka Deploy.

VIKTIGT:
Den här versionen sparar testdata lokalt i webbläsaren (localStorage).
Använd därför INTE riktiga patientuppgifter ännu.
För klinisk användning behöver appen byggas om med inloggning, databas,
behörighetsstyrning, backup och GDPR-/säkerhetsgenomgång.
